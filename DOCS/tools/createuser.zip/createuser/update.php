<?php
## Conn auf lokale DB (oder krepier) ##
$dbH = mysql_connect('localhost', 'root', 'kugelmoped77') or die('Keine Verbindung zum MYSQL-Server.<br>' . mysql_error());

## DB fuer Update auswaehlen## 
mysql_select_db('owltest') or die('Konnte DB nicht finden.<br>' . mysql_error());

## CSV file zum einlesen (Hardcode, die Datei muss immer so heissen) ##
$CSVFile = 'studenten.csv';

mysql_query('LOAD DATA LOCAL INFILE "/var/www/html/createuser/upload/studenten.csv" INTO TABLE users FIELDS TERMINATED BY ";" LINES TERMINATED BY "\\r\\n";') or die('Datenformat ung�ltig oder keine Datei gefunden.<br>' . mysql_error());

## Conn schliessen##
mysql_close($dbH);
unlink ('/var/www/html/createuser/upload/studenten.csv');
echo "<font size=\"2\" font face=\"Verdana\" font color=\"#088551\">Fertig ! Keine Fehler, Datei gel�scht - Have a nice day.</font>";
?>
