<?php

################## konfig ####################

# header und titel dieses files
$title = "Technikum Upload Manager";

# file size limit in bytes
$file_size_ind = "1024000";

# doit directory
$dir_doit= "/var/www/html/createuser/";

# upload store directory (chmod 777)
$dir_store= "/var/www/html/createuser/upload/";

# images directory
$dir_img= "img";

# zu verwendendes stylesheet, liegt in der img-subdir
$style = "style-def";

# zum upload erlaubte filetypen
$file_ext_allow = array("csv");

# dateiliste anzeigen (ja=1;nein=0)
$file_list_allow = 1;

# dateien l�schen erlaubt (ja=1;nein=0)
$file_del_allow = 1;

# passowrtabfrage (ja=1;nein=0) irgendwas hats da, deshalb bitte nicht aktivieren
$auth_ReqPass = 0;

# passwortabfrage, teil 2
# wenn "$auth_ReqPass" aktiviert ist, muss hier l/pw gesetzt werden
$auth_usern = "upload";
$auth_passw = "anlegen";

################ ende der konfig ###############


?>
<?
if (@phpversion() < '4.1.0') {
    $_FILE = $HTTP_POST_FILES;
    $_GET = $HTTP_GET_VARS;
    $_POST = $HTTP_POST_VARS;
}
clearstatcache();
error_reporting(E_ALL & ~E_NOTICE);
$fum_vers = "1.3";
$fum_info_full = "Technikum Upload Manager v$fum_vers";

function authDo($auth_userToCheck, $auth_passToCheck) 
{
	global $auth_usern, $auth_passw;
	$auth_encodedPass = md5($auth_passw);
	
	if ($auth_userToCheck == $auth_usern && $auth_passToCheck == $auth_encodedPass) {
	$auth_check = TRUE;
	} else {
	$auth_check = FALSE;
	} 
	return $auth_check;
	}
	
	if (isset($logout)) {
	setcookie ('fum_user', "",time()-3600); 
	setcookie ('fum_pass', "",time()-3600);
	}
		
	if (isset($login)) {
	$auth_password_en = md5($auth_formPass); 
	$auth_username_en = $auth_formUser;

	if (authDo($auth_username_en, $auth_password_en)) { 
	setcookie ('fum_user', $auth_username_en,time()+3600); 
	setcookie ('fum_pass', $auth_password_en,time()+3600); 
	$auth_msg = "<b>Authentifikation erfolgreich!</b> Cookies gesetzt !<br><br>".
	$auth_msg . "Ihr Passwort lautet (MD5 encrypted): $auth_password_en";
	} else { 
	$auth_msg = "<b>Authentifikationsfehler!</b>";
	}
}

if (($_GET[act]=="dl")&&$_GET[file]) 
{
	if ($auth_ReqPass != 1 || ($auth_ReqPass == 1 && isset($fum_user) && !isset($logout))) { 
	if ($auth_ReqPass != 1 || ($auth_ReqPass == 1 && authDo($fum_user, $fum_pass))) {

	$value_de=base64_decode($_GET[file]);
	$dl_full=$dir_store."/".$value_de;
	$dl_name=$value_de;

	if (!file_exists($dl_full))
	{ 
	echo"ERROR: Uploadfehler, Datei existiert nicht !<br>�<a href=\"$_SERVER[PHP_SELF]\">zur�ck</a>";  
	exit();
	} 
	
	header("Content-Type: application/octet-stream");
	header("Content-Disposition: attachment; filename=$dl_name");
	header("Content-Length: ".filesize($dl_full));
	header("Accept-Ranges: bytes");
	header("Pragma: no-cache");
	header("Expires: 0");
	header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
	header("Content-transfer-encoding: binary");
			
	@readfile($dl_full);
	
	exit();

	}
	}
}

function getlast($toget)
{
	$pos=strrpos($toget,".");
	$lastext=substr($toget,$pos+1);

	return $lastext;
}

function replace($o)
{
	$o=str_replace("/","",$o);
	$o=str_replace("\\","",$o);
	$o=str_replace(":","",$o);
	$o=str_replace("*","",$o);
	$o=str_replace("?","",$o);
	$o=str_replace("<","",$o);
	$o=str_replace(">","",$o);
	$o=str_replace("\"","",$o);
	$o=str_replace("|","",$o);
	
	return $o;
}

?>


<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title><? echo ($title) ? ($title) : ("Technikum Upload Manager"); ?></title>
<link rel="stylesheet" href="<?=$dir_img?>/<?=$style?>.css" type="text/css">
<?
	if ($auth_ReqPass == 1) 
	{ 
		if (isset($login) || isset($logout)) {
			echo("<meta http-equiv='refresh' content='2;url=$_SERVER[PHP_SELF]'>");
		}
	}
?>
</head>
<body bgcolor="#F7F7F7"><br><br>
<center>
<?	
	if ($auth_ReqPass != 1 || ($auth_ReqPass == 1 && isset($fum_user) && !isset($logout))) { 
	if ($auth_ReqPass != 1 || ($auth_ReqPass == 1 && authDo($fum_user, $fum_pass))) {
?>
<table width="560" cellspacing="0" cellpadding="0" border="0">
  <tr>
    <td><font size="3"><b><i><? echo ($title) ? ($title) : ("Technikum Upload Manager"); ?></i></b></font>&nbsp;<font style="text-decoration: bold; font-size: 9px;">v<?=$fum_vers?></font>&nbsp;
<? 
	#UDSSR Skriptkollektiv#
	echo"<a href=\"http://www.udssr.at\" style=\"text-decoration: none; color: #008381; font-size: 9px; cursor: default\";>&copy; UdSSR Skriptkollektiv</a>"; 
?>
    </td>
   </tr>
</table>
<?
	if (!eregi("777",decoct(fileperms($dir_store))))
	{
		echo"<br><br><b><h4><font color=\"FF0000\">FEHLER: Uploaddirectoryfehler, bitte passen Sie die Rechte des Verzeichnisses \"$dir_store\" per chmod 777 (xrw-xrw-xrw) an!</h4></font></b><br>�<a href=\"$_SERVER[PHP_SELF]\">refresh</a>";
	}
	else
	{
		if (!$_FILES[fileupload])
		{
?>
<table width="560" cellspacing="0" cellpadding="0" border="0" class="table_decoration" style="padding-top:5px;padding-left=5px;padding-bottom:5px;padding-right:5px">
  <form method="post" enctype="multipart/form-data">
  <tr>
    <td>Dateiname:</td><td><input type="file" name="fileupload" class="textfield" size="30"></td>
  </tr>
  <tr>
    <td>Umbenennen in:</td><td><input type="text" name="rename" class="textfield" size="46"></td>
  </tr>
  <tr>
    <td>Erlaubte Dateitypen:</td><td>
	<?
	for($i=0;$i<count($file_ext_allow);$i++)
	{
		if (($i<>count($file_ext_allow)-1))$commas=", ";else $commas="";
		list($key,$value)=each($file_ext_allow);
		echo $value.$commas;
	}
	?>
    </td>
  </tr>
  <tr>
    <td>Max. Dateigr�sse:</td>
	<td>
		<b><?
			if ($file_size_ind >= 1048576) 
			{
				$file_size_ind_rnd = round(($file_size_ind/1024000),3) . " MB";
			} 
			elseif ($file_size_ind >= 1024) 
			{	
				$file_size_ind_rnd = round(($file_size_ind/1024),2) . " KB";
			} 
			elseif ($file_size_ind >= 0) 
			{
				$file_size_ind_rnd = $file_size_ind . " bytes";
			} 
			else 
			{
				$file_size_ind_rnd = "0 bytes";
			}
			
			echo "$file_size_ind_rnd";
		?></b>
	</td>
  </tr>
  <tr>
    <td colspan="2"><input type="submit" value="uploaden" class="button">&nbsp;<input type="reset" value="zur�ck" class="button"></td>
  </tr>
    </form>
</table>
<?
		if ((!$_GET[act]||!$_GET[file])&&$_GET[act]!="delall")
		{
			$opendir = @opendir($dir_store);

			while ($readdir = @readdir($opendir))
			{
				if ($readdir<>"." && $readdir<>".." && $readdir != "index.html")
				{
					$filearr[] = $readdir;
				}
				$sort=array();
				for($i=1;$i<=count($filearr);$i++)
				{
					$key = sizeof($filearr)-$i;
					$file = $filearr[$key];

					$sort[$i]=$file;
				}
				asort($sort);
			}
?>
<br>
<table width="560" cellspacing="0" cellpadding="0" border="0" class="table_decoration" style="padding-left:5px">
  <tr>
    <td><b>Dateien l�schen:</b>
<? 
	if ($file_del_allow != 1 && $auth_ReqPass != 1)
	{
		echo"<i>none</i>";
	}

	if ($file_del_allow == 1 && $file_list_allow == 1 && (count($filearr) >= 1)) 
	{ 
		echo"<a href=\"javascript:;\" onClick=\"cf=confirm('Sind Sie sicher, dass Sie ALLE DATEIEN L�SCHEN wollen?');if (cf)window.location='?act=delall'; return false;\" style=\"font-size: 9px;\">&lt;alle Dateien l�schen&gt;</a>";
	}
	
	if ($auth_ReqPass == 1) 
	{ 
		echo"&nbsp;<a href=\"$_SERVER[PHP_SELF]?logout=1\" style=\"font-size: 9px;\">&lt;logout&gt;<a>";
	}
?>
    </td>
  </tr>
</table>
<br>
<?	
			if ($file_list_allow == 1 && (count($filearr) >= 1)) 
			{
?>
<table width="560" cellspacing="0" cellpadding="0" border="0" class="table_decoration" style="padding-left:6px">
  <tr bgcolor="#F2F2F2">
    <td align="left" width="46%">Dateiname</td>
    <td align="center" width="12%">Dateityp</td>
    <td align="center" width="12%">Dateigr�sse</td>
    <td align="center" width="30%">Funktionen</td>
  </tr>
<?
				for($i=1;$i<=count($sort);$i++)
				{
					list($key,$value)=each($sort);

					if ($value)
					{
						$value_en = base64_encode($value);
						$value_view=$value;
						
							if (strlen($value) >= 48) 
							{ 
								$value_view = substr($value_view, 0, 45) . '...';
							}
?>
<tr>
    <td width="30%"><?="<a href=\"?act=view&file=$value_en\">$value_view</a>"?></td>
    <td align="center" width="5%"><? echo strtoupper(getlast($value)); ?></td>
    <td align="center" width="5%"><?

    	$value_full = $dir_store."/".$value;
    	$file_size = filesize($value_full);
		
		if ($file_size >= 1048576) 
		{
			$show_filesize = number_format(($file_size / 1048576),2) . " MB";
		} 
		elseif ($file_size >= 1024) 
		{
			$show_filesize = number_format(($file_size / 1024),2) . " KB";
		} 
		elseif ($file_size >= 0) 
		{
			$show_filesize = $file_size . " bytes";
		} 
		else 
		{
			$show_filesize = "0 bytes";
		}

		echo "$show_filesize";
		
?></td>
    <td align="center" width="5%">
<?
	if ($file_del_allow == 1) 
	{ 
		echo"<a title=\"Download file\" href=\"?act=dl&file=$value_en\">&lt;downloaden&gt;</a>";
 	} 
	else 
	{ 
		echo"<a title=\"Download file\" href=\"?act=dl&file=$value_en\">&lt;downloaden&gt;</a>"; 
	} 

	if ($file_del_allow == 1) 
	{ 
		echo"&nbsp;|&nbsp;<a title=\"Delete file\" href=\"javascript:;\" onClick=\"cf=confirm('Sind Sie sicher, dass Sie diese Datei l�schen wollen ?');if (cf)window.location='?act=del&file=$value_en'; return false;\">&lt;l�schen&gt;</a>";
	} 
	else 
	{ 
		echo"&nbsp;"; 
	} 
?>
    </td>
</tr>
<?
				}
				else
				{
					echo"<br>";
				}
				}
?>
</table>

<table width="560" cellspacing="0" cellpadding="0" border="0" class="table_decoration" style="padding-top:5px;padding-left=5px;padding-bottom:5px;padding-right:5px">
  <form method="post" enctype="multipart/form-data">
<tr>
    <td colspan="2"><input type="submit" onClick="window.open('update.php')" value="Studenten anlegen" class="button"></td>
  </tr>
  </form>
</table>

</center>
<?
			}
		}
		elseif (($_GET[act]=="del")&&$_GET[file])
		{
			$value_de = base64_decode($_GET[file]);
			@unlink($dir_store."/$value_de");
			echo"<br><img src=\"$dir_img/info.gif\" width=\"15\" height=\"15\">&nbsp;<b><font size=\"2\">Datei gel�scht!</font></b><br>�<a href=\"$_SERVER[PHP_SELF]\">zur�ck</a>";
		}
		if ($_GET[act]=="delall")
		{
			$handle = opendir($dir_store);
			while($file=readdir($handle))
			if (($file != ".")&&($file != ".."))
			@unlink($dir_store."/".$file);
			closedir($handle);

			echo"<br><img src=\"$dir_img/info.gif\" width=\"15\" height=\"15\">&nbsp;<b><font size=\"2\">Alle Dateien sind gel�scht worden !</font></b><br>�<a href=\"$_SERVER[PHP_SELF]\">zur�ck</a>";
		}

	}
	else
	{
		echo"<br><br>";
		$uploadpath=$dir_store."/";
		$source=$_FILES[fileupload][tmp_name];
		$fileupload_name=$_FILES[fileupload][name];
		$weight=$_FILES[fileupload][size];

		for($i=0;$i<count($file_ext_allow);$i++)
		{
			if (getlast($fileupload_name)!=$file_ext_allow[$i])
				$test.="~~";
		}
		$exp=explode("~~",$test);

		if (count($exp)==(count($file_ext_allow)+1))
		{
			echo"<br><img src=\"$dir_img/error.gif\" width=\"15\" height=\"15\">&nbsp;<b><font size=\"2\">FEHLER: Falsches Dateiformat (".getlast($fileupload_name).") oder keine Datei angegeben.</font> </b><br>�<a href=\"$_SERVER[PHP_SELF]\">zur�ck</a>";
		}
		else
		{

			if ($weight>$file_size_ind)
			{
				echo"<br><img src=\"$dir_img/error.gif\" width=\"15\" height=\"15\">&nbsp;<b><font size=\"2\">FEHLER: Datei �berschreitet spezifizierte Gr�sse von ".$file_size_ind." BYTES  (".round(($file_size_ind/1024),2)." KB)</font></b><br>�<a href=\"$_SERVER[PHP_SELF]\">zur�ck</a>";
			}
			else
			{

				foreach($_FILES[fileupload] as $key=>$value)
				{
					echo"<font color=\"#3399FF\">$key</font> : $value <br>";
				}

				echo "<br>";

				$dest = ''; 

				if (($source != 'none') && ($source != '' ))
				{
					$dest=$uploadpath.$fileupload_name;
					if ($dest != '')
					{
						if (file_exists($uploadpath.$fileupload_name))
						{
							echo"<br><img src=\"$dir_img/error.gif\" width=\"15\" height=\"15\">&nbsp;<b><font size=\"2\">Fehler: Datei existiert bereits !</font></b><br>�<a href=\"$_SERVER[PHP_SELF]\">zur�ck</a>";
						}
						else
						{
							if (copy($source,$dest))
							{
								if ($_POST[rename])
								{
									$_POST[rename]=replace($_POST[rename]);
									$exfile=explode(".",$fileupload_name);
									
									if (@rename("$dir_store/$fileupload_name","$dir_store/$_POST[rename].".getlast($fileupload_name))) 
									{
										echo"<br><img src=\"$dir_img/info.gif\" width=\"15\" height=\"15\">&nbsp;<b><font size=\"2\">File ist umbenannt worden in $_POST[rename].".getlast($fileupload_name)."!</font></b></font><br>";
									}
								}
								echo"<br><img src=\"$dir_img/info.gif\" width=\"15\" height=\"15\">&nbsp;<b><font size=\"2\">Datei wurde am System gespeichert!</font></b><br>�<a href=\"$_SERVER[PHP_SELF]\">zur�ck</a>";
							}
							else
							{
								echo"<br><img src=\"$dir_img/error.gif\" width=\"15\" height=\"15\">&nbsp;<b><font size=\"2\">UPLOADFEHLER: Bitte Directory auf chmod 777 setzen !</font></b><br>�<a href=\"$_SERVER[PHP_SELF]\">zur�ck</a>";
							}
						}
					}
				}
			}
		}
	}
}

#/# ende des hauptteils, authcode start wenn user nicht eingeloggt ist und der $auth_ReqPass enabled ist

	} 
	else 
	{
		echo("<p><img src=\"$dir_img/error.gif\" width=\"15\" height=\"15\">&nbsp;Authentifikatiosnfehler</p>" .
"<p><a href='$_SERVER[PHP_SELF]?logout=1'>Bitte Cookies l�schen und erneut einloggen<a></p>");
	}
	} 
	else 
	{

	if (!isset($login) || isset($relogin)) {
?>
<font size="3"><b><i><? echo ($title) ? ($title) : ("Technikum Upload Manager"); ?></i> - Authentifikation</b></font><br><br>
<table class="table_auth"><tr><td><center>
Bitte geben Sie Ihren Usernamen und Passwort ein, um in den gesch�tzen Bereich zu gelangen.<br>
Cookies m�ssen aktiviert sein.
</center></td></tr></table>
<form action="<?=$_SERVER[PHP_SELF]?>?login=1" method="POST"><p>
Username: <input type="text" name="auth_formUser" size="20"><br>
Passwort: <input type="password" name="auth_formPass" size="20">
<p><input type="submit" name="submit" class="button" value="Log-In"></p>
</form></center>
<?
	} 
	elseif (isset($login)) 
	{
		echo("<p>$auth_msg</p>" . "<p>Danke, Sie werden weitergeleitet !</p>");
	}
	}
?>
</body>
</html>